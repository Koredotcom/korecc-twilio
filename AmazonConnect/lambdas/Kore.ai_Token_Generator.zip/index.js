import jwt from "jsonwebtoken"

export const handler = async (event) => {
  const { botId, clientId, clientSecret } = event.Details.Parameters
  const token = jwt.sign({
    "iss": clientId,
    "sub": "number",
    "aud": "https://idproxy.kore.com/authorize",
    "botId": botId,
    "isAnonymous": false,
  }, clientSecret)
  console.log("Kore Token :", token)
  const response = {
    "koreiframetoken": token
  };
  return response;
};
