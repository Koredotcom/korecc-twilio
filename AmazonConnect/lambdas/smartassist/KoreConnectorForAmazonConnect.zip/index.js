const { default: axios } = require("axios");
const { v4: uuidv4 } = require("uuid")
const jwt = require("jsonwebtoken")

console.log("=======Begin=======");
let https = require("https");
let host = process.env.koreHost;
let jwtToken = "bearer " + process.env.jwtToken;

function getToken(clientId, clientSecret) {
    return jwt.sign({
        "sub": "1234567890",
        "appId": clientId
    }, clientSecret)
}

function close(sessionAttributes, actionType, fulfillmentState, message, intentName, slots, callback) {
    let resJson = {};
    resJson.sessionAttributes = sessionAttributes;
    if (actionType !== "Close") {
        resJson.dialogAction = {
            type: "ElicitIntent",//actionType,
            // intentName: "PassthroughIntent",//intentName,
            // "fulfillmentState": "Fulfilled",
            // slots: slots,
            //slotToElicit : "userutterance",
            message
        };
    }
    else {
        resJson.dialogAction = {
            type: actionType,
            // "fulfillmentState": "Fulfilled",
            message
        };
    }
    console.log("----------------This is Response sent to Lex--------\n", resJson);
    callback(resJson);
}

// --------------- Events -----------------------

async function dispatch(intentRequest, callback) {
    console.log(`request received for intent=${JSON.stringify(intentRequest)}, userId=${intentRequest.userId}, intentName=${intentRequest.currentIntent.name}`);
    const sessionAttributes = intentRequest.sessionAttributes;
    const { botId, clientId, clientSecret, webhookURL } = sessionAttributes;
    let inputMessage = intentRequest.currentIntent.slots["userutterance"] || intentRequest.inputTranscript;

    const postDataJSON = {
        "session": {
            "new": false
        },
        "message": {
            "text": inputMessage
        },
        "from": {
            "id": intentRequest.userId
        },
        "to": {
            "id": botId

        }
    };

    let actionType = "ElicitIntent";
    let slots = {
        "userutterance": null
    };
    if (!inputMessage || inputMessage === '') {
        console.log("***** Empty transcrit received. Reprompting.... ");
        return close(sessionAttributes, actionType, 'Fulfilled', { 'contentType': 'PlainText', 'content': "Sorry, could you please repeat that?" }, intentRequest.currentIntent.name, slots, callback);
    }

    try {
        console.log("Data posted to Kore :", postDataJSON)
                const token = `Bearer ${getToken(clientId, clientSecret)}`;
        console.log("token",token)
        const response = await axios.post(webhookURL, postDataJSON, { headers: { Authorization: token } });
        const data = response.data

        console.log('Kore Bot Response', data);

        if (data.isTemplate) {
            delete data["isTemplate"];
        }
        if (data.endOfTask) {
            delete data["endOfTask"];
            console.log("\n--------------------------This is when task is completed-----------------\n", data);
        }
        let message = data.text;
        console.log(message);
        if (typeof message === "object") {
            let tempmsg = "";
            for (const element of message) {
                tempmsg += (element + ",\n");
            }
            message = tempmsg;
            close(sessionAttributes, actionType, 'Fulfilled', { 'contentType': 'PlainText', 'content': message }, intentRequest.currentIntent.name, slots, callback);
        }
    } catch (error) {
        console.log('Problem with request:', error);
        close(sessionAttributes, actionType, 'Fulfilled', { 'contentType': 'PlainText', 'content': "Sorry, something went wrong. Please try again!" }, intentRequest.currentIntent.name, slots, callback);
    }
}

// --------------- Main handler -----------------------
exports.handler = async (event, context, callback) => {
    console.log(event);
    try {
        await dispatch(event,
            (response) => {
                callback(null, response);
            });
    } catch (err) {
        callback(err);
    }
};