import jwt from 'jsonwebtoken';

const generateToken = async () => {

  return new Promise((resolve, reject) => {
    try {
      const payload = {
        'iss': process.env.clientId,
        'sub': 'number',
        'aud': 'https://idproxy.kore.com/authorize',
        'botId': process.env.botId,
        'isAnonymous': false
      };
      const token = jwt.sign(payload, process.env.clientSecret, { algorithm: 'HS256' }, { expiresIn: '1d' });
      if (token) {
        console.log("Token generated...");
        resolve(token)
      } else {
        console.log("Error while creating token..........");
        reject(null);
      }
    } catch (error) {
      console.log("Error in Token generation......");
      console.log("-----", error);
    }
  })
}


export const handler = async (event) => {

  console.log("------------------");
  console.log(JSON.stringify(event));
  console.log("------------------");

  try {

      let token = await generateToken();
      let botId = process.env.botId;
      let agentassistUrl = process.env.agentassistUrl;

      console.log("++++++++++++++++++++++++++++++++++");
      console.log(`agentassist:${agentassistUrl}`)
      console.log("++++++++++++++++++++++++++++++++++");

      return {
        statusCode: 200,
        body: JSON.stringify({ botId, token, agentassistUrl, awsConnectURL:process.env.awsConnectURL, languageCode:process.env.languageCode})
      };


  } catch (error) {
    console.log("error::::::::::::", JSON.stringify(error));
    return {
      statusCode: 400,
      body: JSON.stringify({message: "Error occured please the logs"})
    }

  }
};