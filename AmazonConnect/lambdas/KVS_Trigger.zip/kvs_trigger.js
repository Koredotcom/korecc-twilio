'use strict';
const { STSClient, GetSessionTokenCommand } = require("@aws-sdk/client-sts"); // CommonJS import
const { default: axios } = require('axios');
const jwt = require("jsonwebtoken")

const getAWSTokenDetails = async () => {
    const client = new STSClient({
        region: process.env.region,
        credentials:
        {
            accessKeyId: process.env.kvsAccessKeyId,
            secretAccessKey: process.env.kvsSecretAccessKey
        }
    });
    const input = {
        DurationSeconds: 129600,
    };
    const command = new GetSessionTokenCommand(input);
    const response = await client.send(command);

    return response
};

const generateIframeToken = async (botId, clientId, clientSecret) => {
    try {
        const payload = {
            'iss': clientId,
            'sub': 'number',
            'aud': 'https://idproxy.kore.com/authorize',
            'botId': botId,
            'isAnonymous': false
        };
        const token = jwt.sign(payload, clientSecret);
        return token
    } catch (error) {
        console.log("Error in Token generation", error);
    }
}

const generateAudioSocketUrl = async (botId, clientId, clientSecret, wssUrl, sipuri, accountId) => {

    try {
        const payload = {
            "appId": clientId
        }
        let baseUrl = wssUrl;
        let token = jwt.sign(payload, clientSecret, { algorithm: 'HS256' }, { expiresIn: '2d' });

        let url = `${baseUrl}/audiosocket/amazonconnect/?sipuri=${sipuri}&token=${token}&botId=${botId}&accountId=${accountId}&agentassist=true`;
        return url
    } catch (error) {
        console.log("Error in Audiosocket url generation, ", error);
    }
}

const getKoreCredentials = async (event) => {
    const { botId, clientId, clientSecret, agentassistUrl, wssUrl, sipUri, accountId } = event.Details.Parameters;

    try {
        let token = await generateIframeToken(botId, clientId, clientSecret);
        let audioSocketURL = await generateAudioSocketUrl(botId, clientId, clientSecret, wssUrl, sipUri, accountId);

        const transcriberPayload = { botId, token, agentassistUrl, audioSocketURL }
        return transcriberPayload
    } catch (error) {
        return {
            botId: null,
            token: null,
            agentassistUrl: null,
            audioSocketURL: null
        }
    }
}

exports.handler = async (event, context, callback) => {
    const koreCredentials = await getKoreCredentials(event)


    let payload = {
        streamARN: event.Details.ContactData.MediaStreams.Customer.Audio.StreamARN,
        startFragmentNum: event.Details.ContactData.MediaStreams.Customer.Audio.StartFragmentNumber,
        connectContactId: event.Details.ContactData.ContactId,
        languageCode: event.Details.ContactData?.Attributes?.languageCode || "es-US",
        // These default to true for backwards compatability
        streamAudioFromCustomer: true,
        streamAudioToCustomer: true,
        awsTokenData: await getAWSTokenDetails(),
        koreConfig: koreCredentials
    };

    const res = await axios.post(process.env.transcriberURL, payload)

    callback(null, buildResponse());
};

function buildResponse() {
    return {
        // we always return "Success" for now
        lambdaResult: "Success"
    };
}
