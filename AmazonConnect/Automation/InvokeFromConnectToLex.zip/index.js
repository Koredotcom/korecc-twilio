const { default: axios } = require("axios");
const { v4: uuidv4 } = require("uuid")
const jwt = require("jsonwebtoken")
const https = require("https");

function getToken(clientId, clientSecret) {
    return jwt.sign({
        "sub": "1234567890",
        "appId": clientId
    }, clientSecret)
}

async function initiateConnection(event, callback) {
    console.log("Event Received; Details from Flow", event)
    const { botId, clientId, clientSecret, webhookURL } = event.Details.Parameters;
    let identity = `t-${uuidv4()}`;
    console.log("random identity :", identity);

    const postBodyJSON = {
        "session": {
            "new": true
        },
        "message": {
            "text": "how are you"
        },
        "from": {
            "id": identity
        },
        "nlMeta": {
            "intent": "Welcome Dialog"
        },
        "to": {
            "id": botId,
            "userInfo": {
                "firstName": "antony"
            }
        }
    }

    let tempmsg = "";
    try {
        const token = `bearer ${getToken(clientId, clientSecret)}`;
        console.log("token",token)
        const response = await axios.post(webhookURL, postBodyJSON, { headers: { Authorization: token } });
        const data = response.data?.text
        for (const element of data) {
            tempmsg += element;
        }
    } catch (error) {
        console.log("somehing went wrong with the request", error)
    }
    const message = tempmsg.trim();
    console.log("welcome message : ", message);
    callback({ "welcomemsg": message, useNLMeta: 'true', identity });

}

exports.handler = function (event, context, callback) {
    try {
        console.log(event);
        console.log(context)
        initiateConnection(event, function (response) {
            callback(null, response);
        });
    }
    catch (err) {
        callback(err);
    }
};